/* dummy file for external tools to use.  Real file is created by
   newlib configuration. */
